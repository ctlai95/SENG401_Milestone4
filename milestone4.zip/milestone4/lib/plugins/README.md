Plugin directory
================

This directory is meant to be used to add custom PerfCake plugin JARs containing e.g. Senders, Reporters, etc.