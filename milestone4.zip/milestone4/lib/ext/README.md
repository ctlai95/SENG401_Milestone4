Extension directory
===================

This directory is meant to be used to add additional JAR libraries (e.g. JMS provider's client, JDBC driver, etc.).