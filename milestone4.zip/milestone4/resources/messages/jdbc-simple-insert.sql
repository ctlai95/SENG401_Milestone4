insert into persons (person_id, name, date_of_birth) values (persons_seq.nextval, '+ěščřžýáíé=wertzuiopasdfghjklůyxcvnm.1234567890', '01/01/09')
