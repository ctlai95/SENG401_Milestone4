select * from persons
