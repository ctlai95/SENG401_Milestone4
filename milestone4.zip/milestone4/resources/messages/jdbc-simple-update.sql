update persons set name='abcdefghijklmnopqrstuvwxyz0123456789!@#$%^°*()_+-=[]{}:",.?/`~Pada,pada_jahoda,kterou_sni_pan_Lahodaabcdefghijklmnopqrstuvwxyz0123456789!@'
